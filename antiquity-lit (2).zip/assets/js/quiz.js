/* ============================================================
   ТЕСТЫ — логика страницы
   ============================================================ */

(function() {
  const data = window.QUIZZES || {};
  const listBox = document.getElementById('quiz-list');
  const container = document.getElementById('quiz-container');
  if (!listBox || !container) return;

  let activeKey = null;
  let state = null;

  // Список квизов
  function renderList() {
    listBox.innerHTML = '';
    container.style.display = 'none';
    listBox.style.display = '';
    Object.keys(data).forEach(key => {
      const q = data[key];
      const card = document.createElement('button');
      card.className = 'card';
      card.style.textAlign = 'left';
      card.style.cursor = 'pointer';
      card.style.fontFamily = 'inherit';
      card.innerHTML = `
        <div class="card-number">Тест · ${q.questions.length} вопросов</div>
        <div class="card-title">${q.title}</div>
        <p class="card-desc">${q.desc}</p>
        <div class="card-meta"><span>Начать →</span></div>
      `;
      card.addEventListener('click', () => startQuiz(key));
      listBox.appendChild(card);
    });
  }

  function startQuiz(key) {
    activeKey = key;
    const q = data[key];
    state = {
      questions: shuffle([...q.questions]),
      idx: 0,
      answered: false,
      selected: null,
      correctCount: 0,
    };
    listBox.style.display = 'none';
    container.style.display = '';
    renderQ();
  }

  function shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  function renderQ() {
    const total = state.questions.length;
    const q = state.questions[state.idx];
    const pct = ((state.idx) / total) * 100;
    container.innerHTML = `
      <div class="q-progress"><div class="q-progress-fill" style="width:${pct}%"></div></div>
      <div class="q-meta">
        <span>${data[activeKey].title}</span>
        <span>Вопрос ${state.idx + 1} из ${total}</span>
      </div>
      <h2 class="q-question">${escapeHtml(q.q)}</h2>
      <div class="q-options" id="q-options"></div>
      <div class="q-explanation" id="q-explanation"></div>
      <div class="q-actions">
        <button class="btn outline" id="q-skip">К списку тестов</button>
        <button class="btn" id="q-next" disabled>Дальше →</button>
      </div>
    `;
    const optsBox = container.querySelector('#q-options');
    q.opts.forEach((opt, i) => {
      const b = document.createElement('button');
      b.className = 'q-option';
      b.textContent = opt;
      b.addEventListener('click', () => selectOption(i));
      optsBox.appendChild(b);
    });
    container.querySelector('#q-skip').addEventListener('click', renderList);
    container.querySelector('#q-next').addEventListener('click', nextQ);
  }

  function selectOption(i) {
    if (state.answered) return;
    const q = state.questions[state.idx];
    state.answered = true;
    state.selected = i;
    if (i === q.correct) state.correctCount++;

    const optsBox = container.querySelector('#q-options');
    Array.from(optsBox.children).forEach((b, j) => {
      b.disabled = true;
      if (j === q.correct) b.classList.add('correct');
      else if (j === i) b.classList.add('wrong');
    });

    const exp = container.querySelector('#q-explanation');
    exp.innerHTML = `<strong>${i === q.correct ? 'Верно.' : 'Не совсем.'}</strong> ${escapeHtml(q.exp)}`;
    exp.classList.add('show');

    container.querySelector('#q-next').disabled = false;
  }

  function nextQ() {
    if (state.idx < state.questions.length - 1) {
      state.idx++;
      state.answered = false;
      state.selected = null;
      renderQ();
    } else {
      showResult();
    }
  }

  function showResult() {
    const total = state.questions.length;
    const score = state.correctCount;
    const pct = Math.round((score / total) * 100);
    let grade = 'Можно ещё подучить';
    if (pct >= 90) grade = 'Великолепно!';
    else if (pct >= 75) grade = 'Очень хорошо';
    else if (pct >= 60) grade = 'Неплохо';
    else if (pct >= 40) grade = 'Стоит перечитать';

    container.innerHTML = `
      <div class="q-result">
        <div class="q-meta" style="justify-content:center"><span>Результат · ${data[activeKey].title}</span></div>
        <div class="q-result-score">${score} / ${total}</div>
        <div class="q-result-grade">${grade} · ${pct}%</div>
        <div class="btn-row">
          <button class="btn outline" id="q-again">Пройти ещё раз</button>
          <button class="btn" id="q-back">К списку тестов</button>
        </div>
      </div>
    `;
    container.querySelector('#q-again').addEventListener('click', () => startQuiz(activeKey));
    container.querySelector('#q-back').addEventListener('click', renderList);
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }

  renderList();
})();
