/* ============================================================
   ТАЙМЛАЙН — логика страницы
   ============================================================ */

(function() {
  const data = window.TIMELINE || [];
  const container = document.getElementById('tl-container');
  const controlsBox = document.getElementById('tl-controls');
  if (!container) return;

  const periods = {
    'все':                'Все периоды',
    'greece-archaic':     'Греция · архаика',
    'greece-classic':     'Греция · классика',
    'greece-hellenistic': 'Эллинизм',
    'rome-republic':      'Римская республика',
    'rome-empire':        'Римская империя',
  };

  let activePeriod = 'все';

  // Контролы
  Object.keys(periods).forEach(key => {
    const btn = document.createElement('button');
    btn.textContent = periods[key];
    btn.dataset.period = key;
    if (key === activePeriod) btn.classList.add('active');
    btn.addEventListener('click', () => {
      activePeriod = key;
      controlsBox.querySelectorAll('button').forEach(b => b.classList.toggle('active', b.dataset.period === key));
      render();
    });
    controlsBox.appendChild(btn);
  });

  function render() {
    const filtered = (activePeriod === 'все' ? data : data.filter(d => d.period === activePeriod))
      .slice()
      .sort((a, b) => a.sortYear - b.sortYear);

    container.innerHTML = '';
    if (!filtered.length) {
      container.innerHTML = '<p style="text-align:center;color:var(--text-faint);padding:60px 0">В этом периоде событий не найдено.</p>';
      return;
    }

    filtered.forEach((d, i) => {
      const item = document.createElement('div');
      item.className = 'tl-item' + (i % 2 === 1 ? ' right' : '');
      item.dataset.period = d.period;
      item.style.animationDelay = (i * 0.04) + 's';
      item.innerHTML = `
        <div class="tl-card">
          <div class="tl-year">${escapeHtml(d.year)}</div>
          <h3 class="tl-title">${escapeHtml(d.title)}</h3>
          <p class="tl-desc">${escapeHtml(d.desc)}</p>
          <span class="tl-period-label">${escapeHtml(periodLabel(d.period))}</span>
        </div>
      `;
      container.appendChild(item);
    });
  }

  function periodLabel(p) {
    return ({
      'greece-archaic':     'Архаика',
      'greece-classic':     'Классика',
      'greece-hellenistic': 'Эллинизм',
      'rome-republic':      'Республика',
      'rome-empire':        'Империя',
    })[p] || p;
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }

  render();
})();
