/* ============================================================
   ФЛЭШ-КАРТЫ — логика страницы
   ============================================================ */

(function() {
  const data = window.FLASHCARDS || {};
  const stage = document.getElementById('fc-stage');
  const selectBox = document.getElementById('fc-select');
  const progress = document.getElementById('fc-progress');
  const btnPrev = document.getElementById('fc-prev');
  const btnNext = document.getElementById('fc-next');
  const btnShuffle = document.getElementById('fc-shuffle');
  const btnReset = document.getElementById('fc-reset');
  if (!stage) return;

  const sets = Object.keys(data);
  let activeSet = sets[0];
  let cards = [];
  let idx = 0;

  // Заполняем select
  sets.forEach(key => {
    const opt = document.createElement('option');
    opt.value = key;
    opt.textContent = data[key].title;
    selectBox.appendChild(opt);
  });

  selectBox.addEventListener('change', (e) => {
    activeSet = e.target.value;
    loadSet();
  });

  function loadSet() {
    cards = [...(data[activeSet]?.cards || [])];
    idx = 0;
    render();
  }

  function render() {
    stage.innerHTML = '';
    if (!cards.length) {
      stage.innerHTML = '<div class="fc-face" style="position:relative;height:100%">Нет карт в этом наборе.</div>';
      return;
    }
    const c = cards[idx];
    const card = document.createElement('div');
    card.className = 'fc-card';
    card.innerHTML = `
      <div class="fc-face fc-front">
        <h2 class="fc-term">${escapeHtml(c.term)}</h2>
        ${c.pronunciation ? `<div class="fc-pronunc">${escapeHtml(c.pronunciation)}</div>` : ''}
        <div class="fc-hint">нажмите, чтобы перевернуть</div>
      </div>
      <div class="fc-face fc-back">
        <p class="fc-def">${escapeHtml(c.def)}</p>
        <div class="fc-hint">нажмите, чтобы вернуться</div>
      </div>
    `;
    card.addEventListener('click', () => card.classList.toggle('flipped'));
    stage.appendChild(card);

    progress.textContent = `${idx + 1} / ${cards.length}`;
    btnPrev.disabled = idx === 0;
    btnNext.disabled = idx === cards.length - 1;
  }

  btnPrev?.addEventListener('click', () => { if (idx > 0) { idx--; render(); } });
  btnNext?.addEventListener('click', () => { if (idx < cards.length - 1) { idx++; render(); } });
  btnShuffle?.addEventListener('click', () => {
    for (let i = cards.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [cards[i], cards[j]] = [cards[j], cards[i]];
    }
    idx = 0;
    render();
  });
  btnReset?.addEventListener('click', loadSet);

  // Клавиатура
  document.addEventListener('keydown', (e) => {
    if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;
    if (e.key === 'ArrowRight') { btnNext?.click(); }
    else if (e.key === 'ArrowLeft') { btnPrev?.click(); }
    else if (e.key === ' ') { e.preventDefault(); stage.querySelector('.fc-card')?.classList.toggle('flipped'); }
  });

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }

  loadSet();
})();
