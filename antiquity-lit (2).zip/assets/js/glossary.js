/* ============================================================
   ГЛОССАРИЙ — логика страницы
   ============================================================ */

(function() {
  const data = window.GLOSSARY || [];
  const container = document.getElementById('gloss-container');
  const searchInput = document.getElementById('gloss-search');
  const tagsBox = document.getElementById('gloss-tags');
  if (!container) return;

  let activeCat = 'все';
  let query = '';

  // Категории
  const allCats = Array.from(new Set(data.map(d => d.cat))).sort();
  const cats = ['все', ...allCats];

  cats.forEach(c => {
    const btn = document.createElement('button');
    btn.className = 'gloss-tag' + (c === activeCat ? ' active' : '');
    btn.textContent = c;
    btn.dataset.cat = c;
    btn.addEventListener('click', () => {
      activeCat = c;
      tagsBox.querySelectorAll('.gloss-tag').forEach(b => b.classList.toggle('active', b.dataset.cat === c));
      render();
    });
    tagsBox.appendChild(btn);
  });

  // Поиск
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      query = e.target.value.trim().toLowerCase();
      render();
    });
  }

  function render() {
    const filtered = data.filter(d => {
      if (activeCat !== 'все' && d.cat !== activeCat) return false;
      if (query) {
        const hay = (d.term + ' ' + (d.orig||'') + ' ' + d.def).toLowerCase();
        if (!hay.includes(query)) return false;
      }
      return true;
    });

    // Группируем по первой букве
    filtered.sort((a, b) => a.term.localeCompare(b.term, 'ru'));
    const groups = {};
    filtered.forEach(d => {
      const letter = d.term[0].toUpperCase();
      if (!groups[letter]) groups[letter] = [];
      groups[letter].push(d);
    });

    container.innerHTML = '';
    if (filtered.length === 0) {
      container.innerHTML = '<div class="gloss-empty">Ничего не найдено. Попробуйте другой запрос.</div>';
      return;
    }
    const letters = Object.keys(groups).sort((a, b) => a.localeCompare(b, 'ru'));
    letters.forEach(letter => {
      const h = document.createElement('div');
      h.className = 'gloss-letter';
      h.textContent = letter;
      container.appendChild(h);

      groups[letter].forEach(d => {
        const item = document.createElement('div');
        item.className = 'gloss-item';
        item.innerHTML = `
          <h3 class="gloss-term">
            ${escapeHtml(d.term)}
            ${d.orig ? `<span class="gloss-orig">${escapeHtml(d.orig)}</span>` : ''}
            <span class="gloss-cat">${escapeHtml(d.cat)}</span>
          </h3>
          <p class="gloss-def">${escapeHtml(d.def)}</p>
        `;
        container.appendChild(item);
      });
    });
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  }

  render();
})();
