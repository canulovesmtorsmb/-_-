/* ============================================================
   ИСТОРИЯ ЛИТЕРАТУРЫ — общий JS
   ============================================================ */

// --- Burger меню в шапке ---
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav-main');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      nav.classList.toggle('open');
      toggle.setAttribute('aria-expanded', nav.classList.contains('open'));
    });
  }

  // Подсветить текущий пункт в шапке
  const current = location.pathname.replace(/\/+$/, '');
  document.querySelectorAll('.nav-main a').forEach(a => {
    const href = a.getAttribute('href');
    if (!href) return;
    const url = new URL(href, location.href);
    const path = url.pathname.replace(/\/+$/, '');
    if (path === current || (path.endsWith('/index.html') && current.endsWith(path.replace('/index.html','')))) {
      a.classList.add('active');
    }
  });

  // --- TOC: scrollspy ---
  const tocLinks = document.querySelectorAll('.toc a[href^="#"]');
  if (tocLinks.length) {
    const headings = Array.from(tocLinks).map(a => {
      const id = a.getAttribute('href').slice(1);
      return document.getElementById(id);
    }).filter(Boolean);

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const id = entry.target.id;
          tocLinks.forEach(a => {
            a.classList.toggle('active', a.getAttribute('href') === '#' + id);
          });
        }
      });
    }, { rootMargin: '-30% 0px -60% 0px', threshold: 0 });

    headings.forEach(h => observer.observe(h));
  }

  // --- Плавная прокрутка для якорей с учётом sticky-шапки ---
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', (e) => {
      const targetId = link.getAttribute('href').slice(1);
      if (!targetId) return;
      const target = document.getElementById(targetId);
      if (!target) return;
      e.preventDefault();
      const headerH = document.querySelector('.site-header')?.offsetHeight || 0;
      const top = target.getBoundingClientRect().top + window.pageYOffset - headerH - 14;
      window.scrollTo({ top, behavior: 'smooth' });
      history.replaceState(null, '', '#' + targetId);
    });
  });

  // --- Появление контентных секций ---
  if ('IntersectionObserver' in window) {
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('fade-up');
          obs.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -10% 0px' });
    document.querySelectorAll('.observe-anim').forEach(el => obs.observe(el));
  }
});
